var config = {
	database: {
		url: 'mongodb://localhost:27017/data'
	},
	server: {
		host: '127.0.0.1',
		port: '4000'
	}
}

module.exports = config